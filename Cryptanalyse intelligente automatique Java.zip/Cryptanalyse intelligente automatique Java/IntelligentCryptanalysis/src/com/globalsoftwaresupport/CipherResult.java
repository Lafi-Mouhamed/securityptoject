package com.globalsoftwaresupport;

public class CipherResult implements Comparable<CipherResult> {
    private String type;
    private String key;
    private String plainText;
    private double score;

    public CipherResult(String type, String key, String plainText, double score) {
        this.type = type;
        this.key = key;
        this.plainText = plainText;
        this.score = score;
    }

    public String getType() {
        return type;
    }

    public String getKey() {
        return key;
    }

    public String getPlainText() {
        return plainText;
    }

    public double getScore() {
        return score;
    }

    @Override
    public int compareTo(CipherResult other) {
        return Double.compare(other.score, this.score); // Descending order
    }

    @Override
    public String toString() {
        return String.format("Type: %s | Key: %s | Conf: %.2f%%%nPrediction: %s",
                type, key, score * 100, plainText);
    }
}
