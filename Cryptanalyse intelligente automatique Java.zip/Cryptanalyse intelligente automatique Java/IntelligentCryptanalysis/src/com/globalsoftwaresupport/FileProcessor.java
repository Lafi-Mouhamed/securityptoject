package com.globalsoftwaresupport;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileProcessor {

    private List<String> words;

    public FileProcessor() {
        this.words = new ArrayList<>();
        getData();
    }

    private void getData() {

        FileReader fileReader = null;
        BufferedReader bufferedReader = null;

        try {
            // Trying multiple paths to be robust
            File file = new File("src/com/globalsoftwaresupport/english_words.txt");
            if (!file.exists()) {
                file = new File("IntelligentCryptanalysis/src/com/globalsoftwaresupport/english_words.txt");
            }

            fileReader = new FileReader(file);
            bufferedReader = new BufferedReader(fileReader);

            String line = "";

            while ((line = bufferedReader.readLine()) != null) {
                words.add(line.toUpperCase());
            }

            fileReader.close();
            bufferedReader.close();
        } catch (FileNotFoundException e) {
            System.err.println("Dictionary file not found!");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String> getWords() {
        return this.words;
    }
}
