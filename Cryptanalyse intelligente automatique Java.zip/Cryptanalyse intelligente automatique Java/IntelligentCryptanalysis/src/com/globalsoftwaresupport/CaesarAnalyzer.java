package com.globalsoftwaresupport;

public class CaesarAnalyzer {

    private LanguageDetector languageDetector;

    public CaesarAnalyzer() {
        this.languageDetector = new LanguageDetector();
    }

    public CipherResult analyze(String cipherText) {
        double bestScore = -1.0;
        String bestKey = "";
        String bestText = "";

        for (int key = 0; key < Constants.ALPHABET.length(); ++key) {

            String plainText = "";

            for (int i = 0; i < cipherText.length(); ++i) {
                char character = cipherText.charAt(i);
                int charIndex = Constants.ALPHABET.indexOf(character);
                if (charIndex == -1) {
                    plainText += character; // Keep non-alphabet characters
                    continue;
                }
                int decryptedIndex = Math.floorMod(charIndex - key, Constants.ALPHABET.length());
                plainText += Constants.ALPHABET.charAt(decryptedIndex);
            }

            double score = languageDetector.scoreEnglish(plainText);

            if (score > bestScore) {
                bestScore = score;
                bestKey = "" + key;
                bestText = plainText;
            }
        }

        return new CipherResult("Caesar", bestKey, bestText, bestScore);
    }
}
