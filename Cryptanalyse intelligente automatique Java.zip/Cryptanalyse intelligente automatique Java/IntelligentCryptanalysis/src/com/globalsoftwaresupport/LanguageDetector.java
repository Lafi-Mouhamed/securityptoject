package com.globalsoftwaresupport;

import java.util.List;

public class LanguageDetector {

    private FileProcessor fileProcessor;
    private List<String> englishWords;
    private FrequencyAnalysis freqAnalysis;

    public LanguageDetector() {
        this.fileProcessor = new FileProcessor();
        this.englishWords = fileProcessor.getWords();
        this.freqAnalysis = new FrequencyAnalysis();
    }

    public double scoreEnglish(String text) {
        if (text == null || text.isEmpty())
            return 0.0;

        text = text.toUpperCase();
        String cleanText = text.replaceAll("[^A-Z]", "");

        // 1. Dictionary Score
        // Remove punctuation for word matching but keep spaces
        String textForWords = text.replaceAll("[^A-Z ]", " ");
        String[] words = textForWords.split("\\s+");

        double dictionaryScore = 0.0;
        if (words.length > 0) {
            int matches = 0;
            int validWords = 0;
            for (String s : words) {
                if (s.length() < 2)
                    continue; // Skip single letters (noise)
                validWords++;
                if (englishWords.contains(s))
                    matches++;
            }
            if (validWords > 0)
                dictionaryScore = (double) matches / validWords;
        }

        // 2. Frequency Score (Chi-Square)
        // Calculate Chi-Square statistic
        // Lower is better.
        // ChiSq = Sum( (ObsObserved - Expected)^2 / Expected )
        // We use counts. Expected count = Total * Freq[i]

        double[] observedVector = freqAnalysis.getFrequencyVector(cleanText);
        double chiSq = 0.0;

        for (int i = 0; i < 26; ++i) {
            double observed = observedVector[i];
            double expected = Constants.ENGLISH_FREQUENCIES[i];
            if (expected > 0) {
                chiSq += Math.pow(observed - expected, 2) / expected;
            }
        }

        // Convert ChiSq to a 0-1 score.
        // A perfect match is 0. A random text is high (e.g. 0.5+ or more depending on
        // metric).
        // Let's say if chiSq < 0.05 it is VERY ENGLISH.
        // if chiSq > 0.15 it is NOT.
        // Score = 1 / (1 + 10 * chiSq) -> If chiSq=0, Score=1. If chiSq=0.1, Score=0.5.

        double frequencyScore = 1.0 / (1.0 + 20 * chiSq);

        // 3. Hybrid Strategy
        // If text has spaces and meaningful word structure, Dictionary is King.
        // If text has no spaces (1 word), Frequency is King.

        if (words.length > 1) {
            // Mix them, but trust dictionary if it finds matches
            return Math.max(dictionaryScore, frequencyScore);
        } else {
            return frequencyScore;
        }
    }
}
