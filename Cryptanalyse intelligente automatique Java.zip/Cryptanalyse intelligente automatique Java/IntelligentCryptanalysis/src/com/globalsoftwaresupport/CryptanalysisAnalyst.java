package com.globalsoftwaresupport;

public class CryptanalysisAnalyst {

    private CaesarAnalyzer caesarAnalyzer;
    private VigenereAnalyzer vigenereAnalyzer;

    public CryptanalysisAnalyst() {
        this.caesarAnalyzer = new CaesarAnalyzer();
        this.vigenereAnalyzer = new VigenereAnalyzer();
    }

    public CipherResult analyze(String cipherText) {
        // Run both analyzers
        CipherResult caesar = caesarAnalyzer.analyze(cipherText);
        CipherResult vigenere = vigenereAnalyzer.analyze(cipherText);

        // Decision Logic
        // Vigenere is more flexible, so if the scores are very close,
        // Vigenere might just be overfitting (with key length > 1).
        // If Caesar has a high score (> 0.7), it's probably Caesar (or Vigenere with
        // simple key).
        // We prefer "Simpler" explanation (Caesar) if scores are tied.

        System.out.println(String.format("[Analyst] Caesar Score: %.2f | Vigenere Score: %.2f",
                caesar.getScore(), vigenere.getScore()));

        if (caesar.getScore() >= vigenere.getScore() - 0.05) { // Bias towards Caesar slightly
            return caesar;
        }

        return vigenere;
    }
}
