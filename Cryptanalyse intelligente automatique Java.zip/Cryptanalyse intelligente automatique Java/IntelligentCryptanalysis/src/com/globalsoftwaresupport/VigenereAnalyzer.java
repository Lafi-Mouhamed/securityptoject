package com.globalsoftwaresupport;

import java.util.ArrayList;
import java.util.List;

public class VigenereAnalyzer {

    private LanguageDetector languageDetector;
    private FrequencyAnalysis frequencyAnalysis;

    public VigenereAnalyzer() {
        this.languageDetector = new LanguageDetector();
        this.frequencyAnalysis = new FrequencyAnalysis();
    }

    public CipherResult analyze(String cipherText) {
        // 1. Try to guess key length
        // We'll try lengths 1 to 20
        int bestLength = 1;
        double bestIoC = 0.0;

        // Clean text for analysis
        String cleanText = cipherText.toUpperCase().replaceAll("[^A-Z]", "");

        // Calculate IoC for each length
        for (int len = 1; len <= 20; ++len) {
            double currentIoC = calculateAverageIoC(cleanText, len);

            // Simple heuristic based on English IoC ~ 0.065
            // If we are close (within 0.01), this is a strong candidate
            if (currentIoC > bestIoC) {
                bestIoC = currentIoC;
                bestLength = len;
            }

            // 0.06 is a good threshold for English
            if (currentIoC >= 0.06) {
                bestLength = len;
                break;
            }
        }

        // 2. Derive key for best length
        String key = solveKey(cleanText, bestLength);

        // 3. Decrypt
        String plainText = decrypt(cipherText, key); // Pass original text to keep spacing
        double score = languageDetector.scoreEnglish(plainText);

        return new CipherResult("Vigenere", key, plainText, score);
    }

    private double calculateAverageIoC(String text, int keyLength) {
        double sumIoC = 0;
        for (int i = 0; i < keyLength; ++i) {
            StringBuilder col = new StringBuilder();
            for (int j = i; j < text.length(); j += keyLength) {
                col.append(text.charAt(j));
            }
            sumIoC += calculateIoC(col.toString());
        }
        return sumIoC / keyLength;
    }

    private double calculateIoC(String text) {
        if (text.length() < 2)
            return 0;
        int[] counts = new int[26];
        for (char c : text.toCharArray()) {
            counts[c - 'A']++;
        }

        double sum = 0;
        for (int count : counts) {
            sum += count * (count - 1);
        }

        return sum / (text.length() * (text.length() - 1));
    }

    private String solveKey(String text, int length) {
        StringBuilder key = new StringBuilder();

        for (int i = 0; i < length; ++i) {
            StringBuilder col = new StringBuilder();
            for (int j = i; j < text.length(); j += length) {
                col.append(text.charAt(j));
            }
            key.append(solveCaesarShift(col.toString()));
        }

        return key.toString();
    }

    private char solveCaesarShift(String text) {
        double minChiSq = Double.MAX_VALUE;
        int bestShift = 0;

        double[] observedFreqs = frequencyAnalysis.getFrequencyVector(text);

        for (int shift = 0; shift < 26; ++shift) {
            double chiSq = 0;
            for (int i = 0; i < 26; ++i) {
                // Expected freq for this char (unshifted)
                double expected = Constants.ENGLISH_FREQUENCIES[i];
                // Observed freq for char 'i' but it came from (i + shift) in ciphertext
                // So if we assume shift 's', then Cipher 'A' maps to Plain 'A'-s.
                // Actually easier: We shift the OBSERVED vector back by 'shift' and compare to
                // ENGLISH.
                // Or: English[i] should match Observed[(i+shift)%26]

                double observed = observedFreqs[(i + shift) % 26];
                chiSq += Math.pow(observed - expected, 2) / expected;
            }

            if (chiSq < minChiSq) {
                minChiSq = chiSq;
                bestShift = shift;
            }
        }

        return Constants.ALPHABET.charAt(bestShift);
    }

    private String decrypt(String cipherText, String key) {
        String plainText = "";
        String upperText = cipherText.toUpperCase();
        int keyIndex = 0;

        for (int i = 0; i < upperText.length(); ++i) {
            char c = upperText.charAt(i);
            int alphaIdx = Constants.ALPHABET.indexOf(c);

            if (alphaIdx != -1) {
                int index = Math.floorMod(alphaIdx - Constants.ALPHABET.indexOf(key.charAt(keyIndex)),
                        Constants.ALPHABET.length());
                plainText += Constants.ALPHABET.charAt(index);

                keyIndex++;
                if (keyIndex == key.length())
                    keyIndex = 0;
            } else {
                plainText += c; // Keep punctuation
            }
        }

        return plainText;
    }
}
