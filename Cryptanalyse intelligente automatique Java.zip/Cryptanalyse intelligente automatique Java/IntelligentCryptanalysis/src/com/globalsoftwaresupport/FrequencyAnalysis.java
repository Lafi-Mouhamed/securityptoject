package com.globalsoftwaresupport;

import java.util.HashMap;
import java.util.Map;

public class FrequencyAnalysis {

    public Map<Character, Integer> run(String text) {
        text = text.toUpperCase();
        Map<Character, Integer> frequencies = new HashMap<>();

        for (int i = 0; i < Constants.ALPHABET.length(); ++i)
            frequencies.put(Constants.ALPHABET.charAt(i), 0);

        for (int i = 0; i < text.length(); ++i) {
            char c = text.charAt(i);
            if (Constants.ALPHABET.indexOf(c) != -1)
                frequencies.put(c, frequencies.get(c) + 1);
        }
        return frequencies;
    }

    public double[] getFrequencyVector(String text) {
        Map<Character, Integer> freqs = run(text);
        double[] vector = new double[26];
        int total = 0;

        for (int count : freqs.values())
            total += count;
        if (total == 0)
            return vector;

        for (int i = 0; i < 26; ++i) {
            vector[i] = (double) freqs.get(Constants.ALPHABET.charAt(i)) / total;
        }
        return vector;
    }
}
