package com.globalsoftwaresupport;

public class App {

    public static void main(String[] args) {

        CryptanalysisAnalyst analyst = new CryptanalysisAnalyst();
        System.out.println("=== Intelligent Cryptanalysis Tool ===");

        // ---------------------------------------------------------
        // CASE 1: Caesar
        // ---------------------------------------------------------
        String caesarText = "YMJ VZNHPI GWTBS KTJ OZRUX TAJW YMJ QFED ITL";

        System.out.println("\n--- Test Case 1 (Caesar) ---");
        System.out.println("Input: " + caesarText);
        System.out.println(analyst.analyze(caesarText));

        // ---------------------------------------------------------
        // CASE 2: Vigenere
        // ---------------------------------------------------------
        // We generate the cipher ourselves to be sure
        String plain = "CRYPTOGRAPHY IS THE PRACTICE AND STUDY OF TECHNIQUES FOR SECURE COMMUNICATION IN THE PRESENCE OF THIRD PARTIES CALLED ADVERSARIES MORE GENERALLY CRYPTOGRAPHY IS ABOUT CONSTRUCTING AND ANALYZING PROTOCOLS THAT PREVENT THIRD PARTIES OR THE PUBLIC FROM READING PRIVATE MESSAGES";
        String key = "KEY";
        String cipher = encryptVigenere(plain, key);

        System.out.println("\n--- Test Case 2 (Vigenere) ---");
        System.out.println("Plain Length: " + plain.length());
        System.out.println("Key: " + key);
        System.out.println("Cipher: " + cipher);
        System.out.println("... Analyzing ...");
        System.out.println(analyst.analyze(cipher));
    }

    private static String encryptVigenere(String plain, String key) {
        StringBuilder sb = new StringBuilder();
        int keyIndex = 0;
        plain = plain.toUpperCase();
        key = key.toUpperCase();

        for (char c : plain.toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                int pIdx = c - 'A';
                int kIdx = key.charAt(keyIndex) - 'A';
                int cIdx = (pIdx + kIdx) % 26;
                sb.append((char) ('A' + cIdx));
                keyIndex = (keyIndex + 1) % key.length();
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
