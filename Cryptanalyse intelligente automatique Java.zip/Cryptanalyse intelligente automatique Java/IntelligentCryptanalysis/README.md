# Intelligent Cryptanalysis Tool (P1-C1)

Ce projet implémente un outil de cryptanalyse intelligent capable d'analyser automatiquement des messages chiffrés (Caesar ou Vigenère) sans connaître la clé.

## Fonctionnalités

1.  **Détection Automatique** : Le système détermine si le message est chiffré avec Caesar ou Vigenère.
2.  **Cassage Intelligent** :
    *   **Caesar** : Teste toutes les clés et valide avec un dictionnaire et une analyse de fréquence.
    *   **Vigenère** : Utilise l'Indice de Coïncidence pour trouver la longueur de la clé, puis l'Analyse de Fréquence (Chi-Square) pour trouver la clé elle-même.
3.  **Validation Linguistique** : Utilise une approche hybride (Dictionnaire Anglais + Analyse Statistique des Fréquences) pour donner un score de confiance.

## Structure

*   `src/com/globalsoftwaresupport/App.java` : Point d'entrée avec démonstration.
*   `src/com/globalsoftwaresupport/CryptanalysisAnalyst.java` : Le "cerveau" qui orchestre l'analyse.
*   `src/com/globalsoftwaresupport/VigenereAnalyzer.java` : Module de cassage Vigenère.
*   `src/com/globalsoftwaresupport/CaesarAnalyzer.java` : Module de cassage Caesar.
*   `src/com/globalsoftwaresupport/LanguageDetector.java` : Évaluateur de texte (Score 0-1).

## Comment exécuter

1.  Aller dans le dossier :
    ```bash
    cd /Users/ghassen/Desktop/Java/IntelligentCryptanalysis
    ```
2.  Compiler :
    ```bash
    javac -d bin src/com/globalsoftwaresupport/*.java
    ```
3.  Exécuter :
    ```bash
    java -cp bin com.globalsoftwaresupport.App
    ```

## Exemple de Résultat

```text
Type: Vigenere | Key: KEY | Conf: 89.74%
Prediction: CRYPTOGRAPHY IS THE PRACTICE ...
```
